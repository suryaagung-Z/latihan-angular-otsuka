import { MST_PROFILE_CODE } from 'src/constants';
import { MenuItem } from './menu.model';

export const MENU: MenuItem[] = [
  // {
  //   id: 131,
  //   label: 'MENUITEMS.DASHBOARD.TEXT',
  //   icon: 'ri-dashboard-line',
  //   link: '/',
  //   role: ['All']
  // },

  {
    id:132,
    label:'Master',
    icon:'ri-folder-line',
    subItems: [
      {
        id:1,
        label:'Master Role',
        icon:'ri-shield-line',
        link:'/master/role'
      },
      {
        id: 2,
        label: 'Master Department',
        icon: 'ri-building-2-line',
        link: '/master/department'
      }
    ]
  }

  // {
  //   id: 131,
  //   label: 'MENUITEMS.INBOX.TEXT',
  //   icon: 'ri-inbox-line',
  //   link: '/widgets'
  // },

  // {
  //   id: 131,
  //   label: 'MENUITEMS.REPORT.TEXT',
  //   icon: 'ri-file-text-line',
  //   link: '/widgets'
  // },






];
